

# no fol

# sunday
# monday
# monday as holiday
# tues
# wed
# wed as holiday
# thurs
# friday
# saturday

# x

# t-5bd
# t-4bd
# t-3bd
# t-2bd
# t-1bd
# t+0bd
# t+1bd
# t+2bd
# t+3bd
# t+4bd
# t+5bd

# fol


# american
# european
# intenrational

# YYMMDD
# MMDDYY
# DDMMYY